import java.util.List;

public class Warehouse {
    private List<Car> cars;

    public Warehouse() {
    }
}
