public enum CarClass {
    PREMIUM,
    STANDARD,
    BUDGET;

    private CarClass() {
    }
}
